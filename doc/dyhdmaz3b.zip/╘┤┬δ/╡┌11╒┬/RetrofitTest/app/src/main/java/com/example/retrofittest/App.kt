package com.example.retrofittest

class App(val id: String, val name: String, val version: String)